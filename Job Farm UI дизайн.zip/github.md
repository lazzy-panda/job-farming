repo: lazzy-panda/job-farming
branch: main

## Last sync
date: 2026-08-26T13:50:00Z

### Updated in this project
- Собран прототип UI: дашборд, источники, резюме/шаблоны, настройки, оверлеи.
- Дизайн построен по карте UI и скриншотам приложения (GitHub-инструменты в сессии недоступны — код репозитория не читался).
- Палитра и логотип: светлая тема на основе логотипа Job Farming.

## Screen map
| Экран проекта | Компоненты репозитория |
| --- | --- |
| Дашборд | dashboard-page, dashboard-header, plan-panel, job-search, job-cards, pagination |
| Источники | source-page, source-create, pagination |
| Резюме и шаблоны | templates-page |
| Настройки | settings-page, settings-form |
| Оверлеи | sort-menu, vacancy-parse-json, Material snackbar |
| Каталог элементов (в работе) | proxy-page, proxy-create, job-table, job-create, job-filters, filters-menu, status-card |
